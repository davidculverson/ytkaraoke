var R=require("../../chunks/[turbopack]_runtime.js")("server/app/discord/route.js")
R.c("server/chunks/[root-of-the-server]__517c378a._.js")
R.c("server/chunks/[root-of-the-server]__b012eeba._.js")
R.c("server/chunks/_next-internal_server_app_discord_route_actions_e0237a3c.js")
R.m(58670)
module.exports=R.m(58670).exports
