var R=require("../../chunks/[turbopack]_runtime.js")("server/app/room/route.js")
R.c("server/chunks/[root-of-the-server]__481ea5a1._.js")
R.c("server/chunks/[root-of-the-server]__b012eeba._.js")
R.c("server/chunks/_next-internal_server_app_room_route_actions_eabb389e.js")
R.m(67852)
module.exports=R.m(67852).exports
