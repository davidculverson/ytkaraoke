var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image.png/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/node_modules_next_dfa214da._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_516c321f.js")
R.c("server/chunks/[root-of-the-server]__38b51b6c._.js")
R.c("server/chunks/_next-internal_server_app_opengraph-image_png_route_actions_d62f126e.js")
R.m(9191)
module.exports=R.m(9191).exports
