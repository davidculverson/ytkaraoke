var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__8f9c212b._.js")
R.c("server/chunks/[root-of-the-server]__38b51b6c._.js")
R.c("server/chunks/node_modules_next_dfa214da._.js")
R.c("server/chunks/_next-internal_server_app_robots_txt_route_actions_9118e90f.js")
R.m(77067)
module.exports=R.m(77067).exports
