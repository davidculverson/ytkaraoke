module.exports=[77229,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_room_route_actions_eabb389e.js.map