module.exports=[32231,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_discord_route_actions_e0237a3c.js.map