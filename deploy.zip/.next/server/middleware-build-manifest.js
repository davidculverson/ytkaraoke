globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/711d597b816a80c1.js",
    "static/chunks/236f7e5abd6f09ff.js",
    "static/chunks/ac9a338116aab6b6.js",
    "static/chunks/89931398983fcd6f.js",
    "static/chunks/1b76a45123c0ab61.js",
    "static/chunks/63f7a3c2bb8d3bc6.js",
    "static/chunks/turbopack-3ef9c91483e0c1d6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];